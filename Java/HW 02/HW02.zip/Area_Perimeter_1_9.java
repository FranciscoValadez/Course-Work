//Written by: Francisco Valadez
//Assignment: HW02 - Pg. 31 - #1.9
//Class: CS 113
//Date: 4/23/2021
//Description: This program displays the area and perimeter of a rectangle

import java.util.Scanner;

public class Area_Perimeter_1_9
{
   public static void main(String[] args)
   {
      double perimeter = 2 * 4.5 + 2 * 7.9;
      double area = 7.9 * 4.5;
      
      System.out.println("Perimeter is: " + perimeter);
      System.out.println("Area is: " + area);

   }
}