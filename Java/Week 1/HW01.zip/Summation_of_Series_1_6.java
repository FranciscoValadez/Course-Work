/*
Written by: Francisco Valadez
Assignment: HW 1.6
Class: CS 113
Date: 4/21/2021
Description: This program displays the total of the numbers 1-9
*/

import java.util.Scanner;

public class Summation_of_Series_1_6
{
   public static void main(String[] args)
   {
      System.out.println("The total of #'s 1-9 is: " + (1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9));
   }
}