/*
Written by: Francisco Valadez
Assignment: Lab 01 1.3
Class: CS 113
Date: 4/16/2021
Description: This program displays a pattern on the screen
*/

public class Display_A_Pattern
{
   public static void main(String[] args)
   {
      System.out.println("    J     A     V     V     A");
      System.out.println("    J    A A     V   V     A A");
      System.out.println("J   J   AAAAA     V V     AAAAA");
      System.out.println(" J J   A     A     V     A     A");
   }
}