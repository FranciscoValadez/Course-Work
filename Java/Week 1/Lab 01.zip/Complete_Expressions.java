/*
Written by: Francisco Valadez
Assignment: Lab 01 1.5
Class: CS 113
Date: 4/16/2021
Description: This program computes an expression
*/

public class Complete_Expressions
{
   public static void main(String[] args)
   {
      System.out.print("(9.5 x 4.5 - 2.5 x 3) / (45.5 - 3.5) = ");
      System.out.print((9.5 * 4.5 - 2.5 * 3)/(45.5 - 3.5));
   }
}